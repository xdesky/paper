Bộ 6 nhà Noel — mã kín trên tai dán. Cạnh nhận và tên mặt xem sơ đồ cuối assembly_guide.pdf.
In US Letter 100%, không Fit to Page. Đo vạch 40 mm.
Chưa lắp thử bằng giấy thật.
